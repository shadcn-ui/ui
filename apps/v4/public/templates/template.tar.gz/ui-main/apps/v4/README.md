This is a wip registry for the `shadcn` canary version. It has React 19 and Tailwind v4 components.
