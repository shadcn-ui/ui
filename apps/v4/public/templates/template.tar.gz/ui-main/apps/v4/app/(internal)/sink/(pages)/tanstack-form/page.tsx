import { ExampleForm } from "@/app/(internal)/sink/(pages)/tanstack-form/example-form"

export default function TanstackFormPage() {
  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <ExampleForm />
    </div>
  )
}
