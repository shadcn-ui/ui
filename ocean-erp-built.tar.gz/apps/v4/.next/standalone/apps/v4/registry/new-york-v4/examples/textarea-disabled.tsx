import { Textarea } from "@/registry/new-york-v4/ui/textarea"

export default function TextareaDisabled() {
  return <Textarea placeholder="Type your message here." disabled />
}
