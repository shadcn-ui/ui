import { Button } from "@/registry/new-york-v4/ui/button"

export default function ButtonLink() {
  return <Button variant="link">Link</Button>
}
