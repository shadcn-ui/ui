import { Badge } from "@/registry/new-york-v4/ui/badge"

export default function BadgeSecondary() {
  return <Badge variant="secondary">Secondary</Badge>
}
