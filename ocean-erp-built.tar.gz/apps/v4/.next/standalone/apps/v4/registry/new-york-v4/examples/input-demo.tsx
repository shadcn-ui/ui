import { Input } from "@/registry/new-york-v4/ui/input"

export default function InputDemo() {
  return <Input type="email" placeholder="Email" />
}
