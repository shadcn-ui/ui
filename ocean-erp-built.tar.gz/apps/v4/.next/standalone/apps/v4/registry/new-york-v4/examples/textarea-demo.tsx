import { Textarea } from "@/registry/new-york-v4/ui/textarea"

export default function TextareaDemo() {
  return <Textarea placeholder="Type your message here." />
}
