import { Input } from "@/registry/new-york-v4/ui/input"

export default function InputDisabled() {
  return <Input disabled type="email" placeholder="Email" />
}
