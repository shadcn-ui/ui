import { Button } from "@/registry/new-york-v4/ui/button"

export default function ButtonDestructive() {
  return <Button variant="destructive">Destructive</Button>
}
