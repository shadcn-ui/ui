export default function TypographySmall() {
  return (
    <small className="text-sm leading-none font-medium">Email address</small>
  )
}
