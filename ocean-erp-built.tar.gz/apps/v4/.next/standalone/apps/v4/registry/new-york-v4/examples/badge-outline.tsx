import { Badge } from "@/registry/new-york-v4/ui/badge"

export default function BadgeOutline() {
  return <Badge variant="outline">Outline</Badge>
}
